

function Header() {
    return (
        <header className="App-header">Enter your degree and Major</header>
    )
}

export default Header;