

function MainContent() {
    return (
        <main>This is the header</main>
    )
}

export default MainContent;