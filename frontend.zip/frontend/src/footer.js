

function Footer() {
    return (
        <footer className="App-footer">&copy; 2021 University of Newcastle</footer>
    )
}

export default Footer;