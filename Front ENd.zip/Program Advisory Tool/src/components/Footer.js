import React from 'react'

export function Footer (){
    return(
        <div>
            <footer className="App-footer">
                <p>&copy; 2021 UniversityOfNewcastle. All rights Reserved | Term and Conditions</p>
            </footer>
        </div>
    )
}