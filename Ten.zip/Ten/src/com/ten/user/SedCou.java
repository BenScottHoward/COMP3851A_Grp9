package com.ten.user;

public class SedCou {
	private int CNo;
	private String Cname;
	private String classroom;
	private float Ccredit;
	public int getCNo() {
		return CNo;
	}
	public void setCNo(int cNo) {
		CNo = cNo;
	}
	public String getCname() {
		return Cname;
	}
	public void setCname(String cname) {
		Cname = cname;
	}
	public String getClassroom() {
		return classroom;
	}
	public void setClassroom(String classroom) {
		this.classroom = classroom;
	}
	public float getCcredit() {
		return Ccredit;
	}
	public void setCcredit(float ccredit) {
		Ccredit = ccredit;
	}

	
}
